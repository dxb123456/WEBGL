class Main extends egret.DisplayObjectContainer {

    public constructor() {
        super();

        new Sample_MaterialBlend();
    }
}