var Main = (function (_super) {
    __extends(Main, _super);
    function Main() {
        _super.call(this);
        new Sample_ModelTexture();
    }
    var d = __define,c=Main,p=c.prototype;
    return Main;
})(egret.DisplayObjectContainer);
egret.registerClass(Main,'Main');
