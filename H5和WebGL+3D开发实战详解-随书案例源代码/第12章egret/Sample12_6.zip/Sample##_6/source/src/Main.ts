class Main extends egret.DisplayObjectContainer {

   
    public constructor() {
        super();
        var sample = new SampleDirLight();
    }
}