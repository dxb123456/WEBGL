var Main = (function (_super) {
    __extends(Main, _super);
    function Main() {
        _super.call(this);
        var sample = new SampleAnimation();
    }
    var d = __define,c=Main,p=c.prototype;
    return Main;
})(egret.DisplayObjectContainer);
egret.registerClass(Main,'Main');
